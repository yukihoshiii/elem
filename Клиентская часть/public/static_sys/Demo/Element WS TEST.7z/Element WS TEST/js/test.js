window.addEventListener('load', function () {
    // URL WebSocket-сервера (замените на свой)
    var url = 'wss://wselem.xyz:8880/user_api';

    // Глобальные переменные
    var socket = null;
    var isConnected = false;
    var rsaPublic = null;
    var rsaPrivate = null;
    var rsaPublicServer = null;
    var aesKey = null;
    var aesServerKey = null;
    var keysReady = false;
    var socketReady = false;
    var messageQueue = [];
    var processingMessages = false;
    var mesCount = 0;

    // Асинхронная функция для генерации RSA-ключей
    async function generateKeys() {
        var keyPair = await window.crypto.subtle.generateKey({
            name: 'RSA-OAEP',
            modulusLength: 2048,
            publicExponent: new Uint8Array([1, 0, 1]),
            hash: { name: 'SHA-256' }
        }, true, ['encrypt', 'decrypt']);
        rsaPublic = await window.crypto.subtle.exportKey('spki', keyPair.publicKey);
        rsaPrivate = await window.crypto.subtle.exportKey('pkcs8', keyPair.privateKey);
        keysReady = true;
        return true;
    }

    // Обработка очереди сообщений, ожидающих отправки
    function processQueue() {
        if (!socketReady || processingMessages) return;
        processingMessages = true;
        while (messageQueue.length > 0) {
            var message = messageQueue.shift();
            send(message);
        }
        processingMessages = false;
    }

    // Устанавливаем соединение с сервером
    function connect() {
        console.log('Пытаюсь соединиться...');
        socket = new WebSocket(url);

        socket.onopen = async function () {
            console.log('socket_connect');
            await generateKeys();
            var publicKeyPem = arrayBufferToPem(rsaPublic, 'PUBLIC KEY');
            // Отправляем публичный ключ для обмена
            socket.send(JSON.stringify({
                type: 'key_exchange',
                key: publicKeyPem
            }));
            isConnected = true;
            processQueue();
        };

        socket.onmessage = async function (event) {
            var rawData = event.data;

            if (rsaPublicServer) {
                if (aesServerKey) {
                    const unit8Array = await blobToUint8Array(rawData);
                    const decryptedAes = await aesDecrypt(unit8Array, aesKey);
                    const decryptedData = MessagePack.decode(decryptedAes);
                    console.log('Пришло сообщение от сокета:', decryptedData);
                    if (decryptedData.type === 'messenger' && decryptedData.action === 'download_file') {
                        mesCount++;
                        console.log('count: ' + mesCount);
                    }
                } else {
                    const unit8Array = await blobToUint8Array(rawData);
                    const decryptedRsa = await rsaDecrypt(unit8Array, rsaPrivate);
                    const decryptedData = MessagePack.decode(decryptedRsa);

                    if (decryptedData.type && decryptedData.type === 'aes_key') {
                        aesServerKey = decryptedData.key;
                        socketReady = true;
                        console.log('socket_ready');
                        // ВСЁ СОКЕТ ГОТОВ ПИЗДЕТЬ

                        send({
                            type: 'social',
                            action: 'get_online_users'
                        })
                        processQueue();
                    }
                }
            } else {
                var data = JSON.parse(rawData);
                if (data.type === 'key_exchange') {
                    rsaPublicServer = data.key;
                    aesKey = generateAESKey();
                    const aesKeyPayload = MessagePack.encode({
                        type: 'aes_key',
                        key: aesKey
                    });
                    const encryptedPayload = await rsaEncrypt(aesKeyPayload, rsaPublicServer);
                    socket?.send(encryptedPayload);
                }
            }
        };

        socket.onclose = function () {
            disconnect();
            setTimeout(connect, 5000);
        };

        socket.onerror = function () {
            disconnect();
            setTimeout(connect, 5000);
        };
    }

    async function send(data) {
        if (!isConnected || !socket || socket.readyState !== WebSocket.OPEN || !socketReady) {
            console.log('Отправка сообщения на сервер, но сокет не открыт', data);
            messageQueue.push(data);
            return;
        }
    
        const ray_id = generateRayID();
    
        const binaryData = MessagePack.encode({ ray_id, ...data });
        const encrypted = await aesEncrypt(binaryData, aesServerKey);
        socket.send(encrypted);
    
        return new Promise((resolve, reject) => {
            const onMessage = async (event) => {
                try {
                    const unit8Array = await blobToUint8Array(event.data);
                    const decryptedAes = await aesDecrypt(unit8Array, aesKey);
                    const decryptedData = MessagePack.decode(decryptedAes);
    
                    if (decryptedData.ray_id === ray_id) {
                        this.socket.removeEventListener('message', onMessage);
                        resolve(decryptedData);
                    }
                } catch (error) {
                    reject(error);
                }
            };
    
            socket.addEventListener('message', onMessage);
    
            setTimeout(() => {
                socket.removeEventListener('message', onMessage);
                // reject(new Error(`Превышено время ожидания для ray_id: ${ray_id}`));
            }, 5000);
        });
    }
    
    async function generateRayID() {
        const timestamp = Date.now();
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let randomPart = '';
        for (let i = 0; i < 10; i++) {
            randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return `${timestamp}${randomPart}`;
    }

    // Разрыв соединения
    function disconnect() {
        if (socket) {
            if (socket.readyState === WebSocket.OPEN) {
                socket.close();
            }
            socket = null;
        }
        isConnected = false;
        rsaPublic = null;
        rsaPrivate = null;
        rsaPublicServer = null;
        aesKey = null;
        aesServerKey = null;
        keysReady = false;
        socketReady = false;
        console.log('socket_disconnect');
        console.log('socket_not_ready');
    }

    // Запускаем соединение при загрузке страницы
    connect();
});